package com.example.finalproject.database;

import android.app.Application;

import java.util.List;

/**
 * Abstracted Repository as promoted by the Architecture Guide.
 * https://developer.android.com/topic/libraries/architecture/guide.html
 */

public class ProductRepository {

    private static ProductRepository productRepository;
    private ProductDao productDao;

    public static ProductRepository getInstance(Application application) {
        if (productRepository == null) {
            productRepository = new ProductRepository(application);
        }
        return productRepository;
    }

    private ProductRepository(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);
        productDao = db.productDao();
    }

    public List<Product> getProducts() {
        return productDao.getAllProducts();
    }

    public List<Product> getSavedProducts() {
        return productDao.getSavedProducts();
    }

    public void insert(Product product) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            productDao.insert(product);
        });
    }

    public void updateProduct(Product product) {
        AppDatabase.databaseWriteExecutor.execute(() -> {
            productDao.updateProduct(product);
        });
    }
}