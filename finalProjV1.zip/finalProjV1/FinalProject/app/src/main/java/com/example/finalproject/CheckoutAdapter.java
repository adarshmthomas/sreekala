package com.example.finalproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.database.Product;

import java.util.List;

public class CheckoutAdapter extends RecyclerView.Adapter<CheckoutAdapter.MyViewHolder> {

    List<Product> mDataset;

    public CheckoutAdapter(List<Product> dataset) {
        this.mDataset = dataset;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        return new MyViewHolder(layoutInflater.inflate(R.layout.checkout_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.name.setText(mDataset.get(position).name);
        holder.price.setText(mDataset.get(position).price + " CAD");
        holder.size.setText(mDataset.get(position).size);
    }

    @Override
    public int getItemCount() {
        if (mDataset != null)
            return mDataset.size();
        return 0;
    }

    public void setData(List<Product> products) {
        this.mDataset = products;
        notifyDataSetChanged();
    }

    static public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        TextView price;
        TextView size;

        public MyViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.name);
            price = view.findViewById(R.id.price);
            size = view.findViewById(R.id.size);
        }
    }
}
