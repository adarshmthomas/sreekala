package com.example.finalproject;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.database.Product;
import com.example.finalproject.database.ProductRepository;

import java.util.List;

public class CheckoutActivity extends AppCompatActivity {


    private EditText nameEt;
    private EditText emailEt;
    private EditText cardNumberEt;
    private EditText addressEt;
    private TextView totalTv;
    private int totalAmount;

    private RecyclerView recyclerView;
    private CheckoutAdapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private List<Product> mProducts;
    private ProductRepository productRepository;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.checkout_layout);
        productRepository = ProductRepository.getInstance(getApplication());
        nameEt = findViewById(R.id.name_et);
        emailEt = findViewById(R.id.email_et);
        cardNumberEt = findViewById(R.id.card_et);
        addressEt = findViewById(R.id.address_et);
        totalTv = findViewById(R.id.total_tv);

        recyclerView = findViewById(R.id.checkout_list);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        mAdapter = new CheckoutAdapter(mProducts);
        recyclerView.setAdapter(mAdapter);

        Button checkoutBtn = findViewById(R.id.checkout_btn);
        checkoutBtn.setOnClickListener(view -> {
            String nameString = nameEt.getText().toString();
            String emailString = emailEt.getText().toString();
            String cardString = cardNumberEt.getText().toString();
            String addressString = addressEt.getText().toString();
            if (nameString.isEmpty() || emailString.isEmpty() || cardString.isEmpty() || addressString.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Enter All fields", Toast.LENGTH_SHORT).show();
            } else {
                if (totalAmount == 0) {
                    Toast.makeText(getApplicationContext(), "Add at least one item", Toast.LENGTH_SHORT).show();
                } else {
                    new CheckoutProductsTask().execute();
                }
            }
        });

        new GetSavedProductsTask().execute();
    }

    private class GetSavedProductsTask extends AsyncTask<String, Integer, List<Product>> {

        protected List<Product> doInBackground(String... urls) {
            List<Product> products = productRepository.getSavedProducts();
            return products;
        }

        protected void onProgressUpdate(Integer... progress) {
            // nothing to do
        }

        protected void onPostExecute(List<Product> products) {
            mProducts = products;
            mAdapter.setData(mProducts);
            for (Product product : mProducts) {
                totalAmount = totalAmount + product.price;
            }
            totalTv.setText("Total Amount " + totalAmount);
        }
    }

    private class CheckoutProductsTask extends AsyncTask<String, Integer, List<Product>> {

        protected List<Product> doInBackground(String... urls) {
            List<Product> products = productRepository.getSavedProducts();
            for(Product product : products){
                product.setProductSaved(-1);
                productRepository.updateProduct(product);
            }
            return products;
        }

        protected void onProgressUpdate(Integer... progress) {
            // nothing to do
        }

        protected void onPostExecute(List<Product> products) {
            Toast.makeText(getApplicationContext(), "Successfully Checked out", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}
