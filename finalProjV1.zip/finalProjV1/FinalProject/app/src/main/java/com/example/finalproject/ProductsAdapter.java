package com.example.finalproject;

import static com.example.finalproject.detail.ProductDetailActivity.PRODUCT_KEY;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.database.Product;
import com.example.finalproject.detail.ProductDetailActivity;

import java.util.List;

public class ProductsAdapter extends RecyclerView.Adapter<ProductsAdapter.MyViewHolder> {

    private List<Product> products;

    public ProductsAdapter(List<Product> dataset) {
        this.products = dataset;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        return new MyViewHolder(layoutInflater.inflate(R.layout.product_item_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.name.setText(products.get(position).name);
        holder.category.setText(products.get(position).category);
        holder.price.setText(products.get(position).price + " CAD");
        Context context = holder.itemView.getContext();
        int drawable = context.getResources().getIdentifier(products.get(position).image, "drawable", context.getPackageName());
        holder.image.setImageResource(drawable);
        holder.itemView.setOnClickListener(view -> {
            Intent intent = new Intent(view.getContext(), ProductDetailActivity.class);
            Bundle mBundle = new Bundle();
            mBundle.putSerializable(PRODUCT_KEY, products.get(position));
            intent.putExtras(mBundle);
            view.getContext().startActivity(intent);
        });
        if (products.get(position).productSaved == -1) {
            holder.cartIv.setImageDrawable(context.getDrawable(R.drawable.ic_unfav));
        } else {
            holder.cartIv.setImageDrawable(context.getDrawable(R.drawable.ic_fav));
        }
    }

    @Override
    public int getItemCount() {
        if (products != null)
            return products.size();
        return 0;
    }

    public void setData(List<Product> products) {
        this.products = products;
        notifyDataSetChanged();
    }

    static public class MyViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        ImageView cartIv;
        TextView name;
        TextView category;
        TextView price;

        public MyViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.name);
            category = view.findViewById(R.id.category);
            price = view.findViewById(R.id.price);
            image = view.findViewById(R.id.image);
            cartIv = view.findViewById(R.id.cart);
        }
    }
}
