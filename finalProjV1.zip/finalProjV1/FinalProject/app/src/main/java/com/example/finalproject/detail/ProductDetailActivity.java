package com.example.finalproject.detail;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.viewpager2.widget.ViewPager2;

import com.example.finalproject.CheckoutActivity;
import com.example.finalproject.database.Product;
import com.example.finalproject.database.ProductRepository;
import com.example.finalproject.R;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

public class ProductDetailActivity extends Activity {

    public static final String PRODUCT_KEY = "product_key";
    private Object selectedChipTag = null;
    private String selectedSizeText;
    private Product selectedProduct;

    private TextView nameTv;
    private TextView categoryTv;
    private TextView descriptionTv;
    private TextView priceTv;
    private Button checkoutBtn;
    private ImageView cartIv;
    private ViewPager2 vPager;
    private ChipGroup chipGroup;
    private TabLayout tabLayout;
    private boolean isSubmitButtonClicked;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_detail_activity);
        selectedProduct = (Product) getIntent().getExtras().getSerializable(PRODUCT_KEY);
        setUiContent();
    }

    private void setUiContent() {
        nameTv = findViewById(R.id.product_name);
        categoryTv = findViewById(R.id.product_category);
        descriptionTv = findViewById(R.id.product_desc);
        priceTv = findViewById(R.id.product_price);
        checkoutBtn = findViewById(R.id.checkoutBtn);
        cartIv = findViewById(R.id.cartIv);
        vPager = findViewById(R.id.vPager);
        chipGroup = findViewById(R.id.size_chips);
        tabLayout = findViewById(R.id.tab_layout);

        nameTv.setText(selectedProduct.name);
        categoryTv.setText(selectedProduct.category);
        descriptionTv.setText(selectedProduct.description);
        priceTv.setText(selectedProduct.price + "CAD");
        checkoutBtn.setOnClickListener(view -> {
            isSubmitButtonClicked = true;
            updateCart();
        });
        setImageGallery();
        setSizeData();
        setCartUi();
    }

    private void setCartUi() {
        if (selectedProduct.productSaved == -1) {
            cartIv.setImageDrawable(getDrawable(R.drawable.ic_unfav));
        } else {
            cartIv.setImageDrawable(getDrawable(R.drawable.ic_fav));
        }
        cartIv.setOnClickListener(view -> {
            isSubmitButtonClicked = false;
            if (selectedProduct.productSaved == 1) {
                selectedProduct.setProductSaved(-1);
                cartIv.setImageDrawable(getDrawable(R.drawable.ic_unfav));
            } else {
                selectedProduct.setProductSaved(1);
                cartIv.setImageDrawable(getDrawable(R.drawable.ic_fav));
            }
            updateCart();
        });

    }

    private void updateCart() {
        selectedProduct.size = selectedSizeText;
        new UpdateProductTask(getApplication(), selectedProduct, false).execute();
    }

    private void setSizeData() {
        String[] sizeValues = getResources().getStringArray(R.array.size_array);
        for (String val : sizeValues) {
            Chip chip = new Chip(this);
            chip.setChipBackgroundColor(getResources().getColorStateList(R.color.chip_color_state));
            chip.setText(val);
            chip.setTag(val);
            if (selectedProduct.size.equals(val)) {
                chip.setChecked(true);
                chip.setSelected(true);
                selectedSizeText = val;
                selectedChipTag = val;
            } else {
                chip.setChecked(false);
                chip.setSelected(false);
            }
            chip.setOnClickListener(view -> {
                if (selectedChipTag != null && view.getTag() != selectedChipTag) {
                    Chip prevSelectedChip = chipGroup.findViewWithTag(selectedChipTag);
                    prevSelectedChip.setSelected(false);
                    prevSelectedChip.setChecked(false);
                    selectedSizeText = null;
                    selectedChipTag = null;
                }
                boolean selected = chip.isSelected();
                chip.setChecked(!selected);
                chip.setSelected(!selected);
                if (chip.isSelected()) {
                    selectedSizeText = chip.getText().toString();
                    selectedChipTag = chip.getTag();
                }
            });
            chipGroup.addView(chip);
        }
    }

    private void setImageGallery() {
        ImageGalleryAdapter adapter = new ImageGalleryAdapter(selectedProduct.image);
        vPager.setAdapter(adapter);
        new TabLayoutMediator(tabLayout, vPager, (tab, position) -> {
            // some implementation
        }).attach();
    }

    private class UpdateProductTask extends AsyncTask<String, Integer, String> {
        private Application application;
        private Product product;

        public UpdateProductTask(Application application, Product selectedProduct, boolean isSubmitBtnclicked) {
            this.application = application;
            this.product = selectedProduct;
        }

        protected String doInBackground(String... urls) {
            ProductRepository productRepository = ProductRepository.getInstance(getApplication());
            productRepository.updateProduct(product);
            return null;
        }

        protected void onProgressUpdate(Integer... progress) {
            // nothing to do
        }

        protected void onPostExecute(String result) {
            if (isSubmitButtonClicked) {
                Intent intent = new Intent(ProductDetailActivity.this, CheckoutActivity.class);
                startActivity(intent);
                finish();
            } else {
                if (selectedProduct.productSaved == 1) {
                    Toast.makeText(application, "Added to Cart", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(application, "Removed from Cart", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}
