package com.example.finalproject;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText userEt;
    private EditText passwordEt;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
        userEt = findViewById(R.id.username_et);
        passwordEt = findViewById(R.id.password_et);
        Button submitBtn = findViewById(R.id.submit_btn);

        submitBtn.setOnClickListener(view -> {
            String usernameString = userEt.getText().toString();
            String passwordString = passwordEt.getText().toString();

            if (usernameString.equals("admin") && passwordString.equals("admin")) {
                Intent intent = new Intent(LoginActivity.this, AdminScreenActivity.class);
                startActivity(intent);
            } else if (usernameString.equals("user1") && passwordString.equals("pass1")) {
                SharedPreferences sharedPref = getSharedPreferences(
                        AppConstants.APP_PREFERENCE, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putBoolean(AppConstants.NORMAL_USER_TYPE, true);
                editor.apply();
                Intent intent = new Intent(LoginActivity.this, ProductListingActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Enter Valid Credentials", Toast.LENGTH_SHORT).show();
            }
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        userEt.setText("");
        passwordEt.setText("");
    }
}
