package com.example.finalproject;

public class AppConstants {
    public static String APP_PREFERENCE = "shared_preference";
    public static String NORMAL_USER_TYPE = "normal_user";
}