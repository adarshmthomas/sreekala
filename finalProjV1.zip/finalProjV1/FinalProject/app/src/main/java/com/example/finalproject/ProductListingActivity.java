package com.example.finalproject;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.database.Product;
import com.example.finalproject.database.ProductRepository;

import java.util.List;

public class ProductListingActivity extends AppCompatActivity {

    private ProductRepository productRepository;
    private RecyclerView recyclerView;
    private ProductsAdapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private List<Product> mProducts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setUiContent();
    }

    private void setUiContent() {
        recyclerView = findViewById(R.id.list);
        layoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(layoutManager);
        mAdapter = new ProductsAdapter(mProducts);
        recyclerView.setAdapter(mAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        new GetProductsTask().execute();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.toolbar_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_checkout: {
                Intent intent = new Intent(ProductListingActivity.this, CheckoutActivity.class);
                startActivity(intent);
                break;
            }
            case R.id.action_logout: {
                SharedPreferences sharedPref = getSharedPreferences(
                        AppConstants.APP_PREFERENCE, Context.MODE_PRIVATE);
                sharedPref.edit().putBoolean(AppConstants.NORMAL_USER_TYPE, false).apply();
                Intent intent = new Intent(ProductListingActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
                break;
            }
        }
        return true;
    }

    private class GetProductsTask extends AsyncTask<String, Integer, List<Product>> {

        protected List<Product> doInBackground(String... urls) {
            productRepository = ProductRepository.getInstance(getApplication());
            List<Product> products = productRepository.getProducts();
            return products;
        }

        protected void onProgressUpdate(Integer... progress) {
            // nothing to do
        }

        protected void onPostExecute(List<Product> products) {
            mProducts = products;
            mAdapter.setData(mProducts);
        }
    }
}