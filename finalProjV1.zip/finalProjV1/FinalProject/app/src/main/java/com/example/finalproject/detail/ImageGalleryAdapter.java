package com.example.finalproject.detail;

import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.finalproject.R;

public class ImageGalleryAdapter extends RecyclerView.Adapter<ImageGalleryAdapter.ViewHolder> {

    private String imageName;

    public ImageGalleryAdapter(String imageName) {
        this.imageName = imageName;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pager_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Drawable drawable = holder.itemView.getContext().getResources().getDrawable(holder.itemView.getContext().getResources().getIdentifier(imageName +"_" + position,
                "drawable", holder.itemView.getContext().getPackageName()));
        holder.shoeIv.setImageDrawable(drawable);
    }


    @Override
    public int getItemCount() {
        return 3;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView shoeIv;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            shoeIv = itemView.findViewById(R.id.shoe_iv);
        }
    }
}
