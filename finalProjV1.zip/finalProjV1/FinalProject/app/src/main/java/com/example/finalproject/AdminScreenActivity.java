package com.example.finalproject;

import android.app.Application;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.finalproject.database.Product;
import com.example.finalproject.database.ProductRepository;

public class AdminScreenActivity extends AppCompatActivity {

    EditText nameEt;
    EditText categoryEt;
    EditText descriptionEt;
    EditText priceEt;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_home);
        nameEt = findViewById(R.id.name_et);
        categoryEt = findViewById(R.id.category_et);
        descriptionEt = findViewById(R.id.desc_et);
        priceEt = findViewById(R.id.price_et);
        Button saveBtn = findViewById(R.id.save_btn);

        saveBtn.setOnClickListener(view -> {
            String name = nameEt.getText().toString();
            String category = categoryEt.getText().toString();
            String desc = descriptionEt.getText().toString();
            String price = priceEt.getText().toString();

            if (name.isEmpty() || category.isEmpty() || desc.isEmpty() || price.isEmpty()) {
                Toast.makeText(getApplicationContext(), "Please enter values in all fields",
                        Toast.LENGTH_SHORT).show();
            } else {
                Product product = new Product();
                product.setName(name);
                product.setCategory(category);
                product.setDescription(desc);
                product.setPrice(Integer.parseInt(price));
                product.setImage("nike");
                new InsertProductTask(getApplication(), product).execute();
            }
        });
    }

    private class InsertProductTask extends AsyncTask<String, Integer, String> {
        private Application application;
        private Product product;

        public InsertProductTask(Application application, Product product) {
            this.application = application;
            this.product = product;
        }

        protected String doInBackground(String... urls) {
            ProductRepository productRepository = ProductRepository.getInstance(getApplication());
            productRepository.insert(product);
            return null;
        }

        protected void onProgressUpdate(Integer... progress) {
            // nothing to do
        }

        protected void onPostExecute(String result) {
            Toast.makeText(application, "Product Successfully Added", Toast.LENGTH_SHORT).show();
            nameEt.setText("");
            categoryEt.setText("");
            descriptionEt.setText("");
            priceEt.setText("");
        }
    }
}
